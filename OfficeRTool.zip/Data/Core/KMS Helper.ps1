# powershell catch exception codes for wmi query
# https://stackoverflow.com/questions/29923588/powershell-catch-exception-codes-for-wmi-query

# gwim ... gcim ... maybe i change it later ...
# gwmi is much better, GetPropertyValue, method invoke .. etc

if ($Args[0] -eq '/QUERY_BASIC') {
 $class = $Args[2];
 $value = @($Args[1]).Replace(' ','')
 $wmi_Object = gwmi -Query "select $($value) from $($class)" -ErrorAction SilentlyContinue
 if (-not $wmi_Object) { return }
 foreach ($item in $wmi_Object) {
  $line = '';
  $value.Split(",")|%{$line += ",$($item.GetPropertyValue("$_"))"}
  Write-Host $line
 }
}

if ($Args[0] -eq '/QUERY_ADVENCED') {
 $class  = $Args[2];
 $filter = $Args[3];
 $value  = @($Args[1]).Replace(' ','')
 $wmi_Object = gwmi -Query "select $($value) from $($class) where ($($filter))" -ErrorAction SilentlyContinue
 if (-not $wmi_Object) { return }
 foreach ($item in $wmi_Object) {
  $line = '';
  $value.Split(",")|%{$line += ",$($item.GetPropertyValue("$_"))"}
  Write-Host $line
 }
}

if ($Args[0] -eq '/ACTIVATE') {
 $CLASS = $Args[1]
 $ID    = $Args[2]
 $ErrorActionPreference = "Stop"
  try {
   $wmi_Object = gwmi -Query "select * from $($CLASS) where ID='$($ID)'"
   $wmi_Object.Activate()
   return "Error:0"
 }
 catch {
  # return wmi last error, in hex format
  $HResult = �{0:x}� -f  @($_.Exception).HResult
  return "Error:$($HResult)"
 }
}

if ($Args[0] -eq '/UninstallProductKey') {
 $CLASS  = $Args[1]
 $FILTER = $Args[2]
 $wmi_Object = gwmi -Query "select * from $($CLASS) where ($($FILTER))"
 if (-not $wmi_Object) { return }
 foreach ($item in $wmi_Object) {
  try {
	  $item.UninstallProductKey()
  }
  catch {
  }
 }
}

if ($Args[0] -eq '/InstallProductKey') {
 $KEY  = $Args[1]
 $LicensingService = gwmi -Query "select * from SoftwareLicensingService"
 try {
  $LicensingService.InstallProductKey($KEY)
 }
 catch {
	 return
 }
}

if ($Args[0] -eq '/InstallLicense') {
 $LicenseFile      = $Args[1]
 $LicensingService = gwmi -Query "select * from SoftwareLicensingService"
 try {
  $LicensingService.InstallLicense(
   [System.IO.File]::ReadAllText(
     $LicenseFile
  ))
 }
 catch {
	 return
 }
}

return $null