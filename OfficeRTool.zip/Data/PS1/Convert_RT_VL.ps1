$arr = @(
  @('MondoRetail','MondoVolume'),
  @('OneNoteRetail','OneNoteVolume'),
  @('ProPlusRetail','ProPlusVolume'),
  @('ProPlus2019Retail','ProPlus2019Volume'),
  @('ProPlus2021Retail','ProPlus2021Volume'),
  @('StandardRetail','StandardVolume'),
  @('Standard2019Retail','Standard2019Volume'),
  @('Standard2021Retail','Standard2021Volume'),
  @('ProjectProRetail','ProjectProVolume'),
  @('ProjectPro2019Retail','ProjectPro2019Volume'),
  @('ProjectPro2021Retail','ProjectPro2021Volume'),
  @('ProjectStdRetail','ProjectStdVolume'),
  @('ProjectStd2019Retail','ProjectStd2019Volume'),
  @('ProjectStd2021Retail','ProjectStd2021Volume'),
  @('VisioProRetail','VisioProVolume'),
  @('VisioPro2019Retail','VisioPro2019Volume'),
  @('VisioPro2021Retail','VisioPro2021Volume'),
  @('VisioStdRetail','VisioStdVolume'),
  @('VisioStd2019Retail','VisioStd2019Volume'),
  @('VisioStd2021Retail','VisioStd2021Volume'),
  @('WordRetail','WordVolume'),
  @('Word2019Retail','Word2019Volume'),
  @('Word2021Retail','Word2021Volume'),
  @('ExcelRetail','ExcelVolume'),
  @('Excel2019Retail','Excel2019Volume'),
  @('Excel2021Retail','Excel2021Volume'),
  @('PowerpointRetail','PowerpointVolume'),
  @('Powerpoint2019Retail','Powerpoint2019Volume'),
  @('Powerpoint2021Retail','Powerpoint2021Volume'),
  @('OutlookRetail','OutlookVolume'),
  @('Outlook2019Retail','Outlook2019Volume'),
  @('Outlook2021Retail','Outlook2021Volume'),
  @('AccessRetail','AccessVolume'),
  @('Access2019Retail','Access2019Volume'),
  @('Access2021Retail','Access2021Volume'),
  @('PublisherRetail','PublisherVolume'),
  @('Publisher2019Retail','Publisher2019Volume'),
  @('Publisher2021Retail','Publisher2021Volume'),
  @('SkypeForBusinessRetail','SkypeForBusinessVolume'),
  @('SkypeForBusiness2019Retail','SkypeForBusiness2019Volume'),
  @('ProPlusSPLA2021Volume','ProPlus2021Volume'),
  @('StandardSPLA2021Volume','Standard2021Volume'),
  @('ProjectProXVolume','ProjectProVolume'),
  @('ProjectStdXVolume','ProjectStdVolume'),
  @('VisioProXVolume','VisioProVolume'),
  @('VisioStdXVolume','VisioStdVolume'),
  @('O365ProPlusVolume','O365ProPlusRetail'),
  @('O365HomePremVolume','O365HomePremRetail'),
  @('O365BusinessVolume','O365BusinessRetail')
)

$clr = Join-Path -Path $env:windir -ChildPath 'Temp\ONAME_CHANGE.REG'
if (test-path $clr) {
	$gcr  = Get-Content -Encoding Unicode $clr
	foreach ($itm in $arr) {
		#$gcr = $gcr.Replace($itm[0], $itm[1])
		$gcr = $gcr -replace $itm[0], $itm[1]
	}
	Set-Content -value $gcr -Encoding Unicode $clr
}