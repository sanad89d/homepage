// ============================================================
// FIREFOX - PRIVACY / HARDENING
// ============================================================

// ------------------------------------------------------------
// TRACKING PROTECTION / PRIVACY
// ------------------------------------------------------------

user_pref("privacy.firstparty.isolate", true);
user_pref("privacy.resistFingerprinting", true);
user_pref("privacy.trackingprotection.enabled", true);
user_pref("privacy.trackingprotection.fingerprinting.enabled", true);
user_pref("privacy.trackingprotection.cryptomining.enabled", true);
user_pref("privacy.globalprivacycontrol.enabled", true);
user_pref("privacy.globalprivacycontrol.functionality.enabled", true);

// ------------------------------------------------------------
// COOKIES
// ------------------------------------------------------------

// Block cross-site tracking cookies
user_pref("network.cookie.cookieBehavior", 1);

// Clear cookies according to lifetime policy
user_pref("network.cookie.lifetimePolicy", 2);

// ------------------------------------------------------------
// GEOLOCATION
// ------------------------------------------------------------

user_pref("geo.enabled", false);

// Do not use Mozilla's network geolocation service
user_pref("geo.provider.network.url", "");

// ------------------------------------------------------------
// WEBRTC / MEDIA
// ------------------------------------------------------------

// Disable WebRTC
user_pref("media.peerconnection.enabled", false);

// Disable media device enumeration
user_pref("media.navigator.enabled", false);

// Disable hardware media keys
user_pref("media.hardwaremediakeys.enabled", false);

// ------------------------------------------------------------
// WEBGL
// ------------------------------------------------------------

user_pref("webgl.disabled", true);

// ------------------------------------------------------------
// CLIPBOARD / BEACON / PINGS
// ------------------------------------------------------------

user_pref("dom.event.clipboardevents.enabled", false);
user_pref("beacon.enabled", false);
user_pref("browser.send_pings", false);

// ------------------------------------------------------------
// NETWORK PREFETCH / SPECULATIVE CONNECTIONS
// ------------------------------------------------------------

user_pref("browser.urlbar.speculativeConnect.enabled", false);

user_pref("network.dns.disablePrefetch", true);
user_pref("network.dns.disablePrefetchFromHTTPS", true);

user_pref("network.predictor.enabled", false);
user_pref("network.predictor.enable-prefetch", false);
user_pref("network.prefetch-next", false);

// ------------------------------------------------------------
// REFERER
// ------------------------------------------------------------

user_pref("network.http.referer.XOriginPolicy", 2);
user_pref("network.http.referer.XOriginTrimmingPolicy", 2);

// Do not send HTTP Referer headers
user_pref("network.http.sendRefererHeader", 0);

// ------------------------------------------------------------
// IDN
// ------------------------------------------------------------

// Display internationalized domain names as punycode
user_pref("network.IDN_show_punycode", true);

// ------------------------------------------------------------
// SEARCH SUGGESTIONS
// ------------------------------------------------------------

user_pref("browser.search.suggest.enabled", false);
user_pref("browser.search.suggest.enabled.private", false);

// ------------------------------------------------------------
// NEW TAB / SPONSORED CONTENT
// ------------------------------------------------------------

user_pref(
    "browser.newtabpage.activity-stream.showSponsoredTopSites",
    false
);

user_pref(
    "services.sync.prefs.sync.browser.newtabpage.activity-stream.showSponsoredTopSites",
    false
);

user_pref(
    "browser.newtabpage.activity-stream.section.highlights.includePocket",
    false
);

// ------------------------------------------------------------
// TELEMETRY / PING / CRASH REPORTING
// ------------------------------------------------------------

user_pref("browser.newtabpage.activity-stream.feeds.telemetry", false);
user_pref("browser.ping-centre.telemetry", false);
user_pref("browser.tabs.crashReporting.sendReport", false);
user_pref("devtools.onboarding.telemetry.logged", false);

user_pref("toolkit.telemetry.enabled", false);
user_pref("toolkit.telemetry.unified", false);

// Empty telemetry server
user_pref("toolkit.telemetry.server", "");

// ------------------------------------------------------------
// POCKET
// ------------------------------------------------------------

user_pref("extensions.pocket.enabled", false);

// ------------------------------------------------------------
// FIREFOX ACCOUNT / SYNC
// ------------------------------------------------------------

user_pref("identity.fxaccounts.enabled", false);

// ------------------------------------------------------------
// FIREFOX UI / FEATURES
// ------------------------------------------------------------

// Disable URL-bar group labels
user_pref("browser.urlbar.groupLabels.enabled", false);

// Sort Ctrl+Tab by tab order rather than MRU
user_pref("browser.ctrlTab.sortByRecentlyUsed", false);

// Warn before closing multiple tabs/windows
user_pref("browser.tabs.warnOnClose", true);

// Disable "More from Mozilla"
user_pref("browser.preferences.moreFromMozilla", false);

// Enable tab groups
user_pref("browser.tabs.groups.enabled", true);

// Enable Fission / site isolation
user_pref("fission.autostart", true);

// Do not retain closed-tab undo history
user_pref("browser.sessionstore.max_tabs_undo", 0);

// Reduce information stored by session restore
user_pref("browser.sessionstore.privacy_level", 2);

// ------------------------------------------------------------
// SAFE BROWSING DOWNLOAD CHECKS
// ------------------------------------------------------------

// Disable remote download reputation checking
user_pref("browser.safebrowsing.downloads.remote.enabled", false);

// Empty remote download-check URL
user_pref("browser.safebrowsing.downloads.remote.url", "");

// ------------------------------------------------------------
// DRM / WIDEVINE
// ------------------------------------------------------------

// Disable Encrypted Media Extensions
user_pref("media.eme.enabled", false);

// Disable Widevine CDM
user_pref("media.gmp-widevinecdm.enabled", false);

// ------------------------------------------------------------
// PDF JAVASCRIPT
// ------------------------------------------------------------

// Disable JavaScript inside PDF.js documents
user_pref("pdfjs.enableScripting", false);

// ------------------------------------------------------------
// TLS / SECURITY
// ------------------------------------------------------------

// Disable obsolete 3DES cipher
user_pref("security.ssl3.rsa_des_ede3_sha", false);

// Require safe TLS negotiation
user_pref("security.ssl.require_safe_negotiation", true);

// ------------------------------------------------------------
// NOTIFICATIONS
// ------------------------------------------------------------

user_pref("dom.webnotifications.enabled", false);

// ------------------------------------------------------------
// FINGERPRINTING
// ------------------------------------------------------------

// Resist fingerprinting
user_pref("privacy.resistFingerprinting", true);

// ------------------------------------------------------------
// GLOBAL PRIVACY CONTROL
// ------------------------------------------------------------

user_pref("privacy.globalprivacycontrol.enabled", true);
user_pref("privacy.globalprivacycontrol.functionality.enabled", true);
