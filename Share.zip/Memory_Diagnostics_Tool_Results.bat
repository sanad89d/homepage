@echo off
powershell -Command "Get-WinEvent -FilterHashTable @{LogName='System'; Id=1101,1201} -ErrorAction Ignore | Where {$_.ProviderName -Match 'MemoryDiagnostics-Results'}"
pause
