@echo off
setlocal enabledelayedexpansion

echo ================================================
echo   Saved Wi-Fi Profiles & Passwords (if stored)
echo ================================================
echo.

:: Get all Wi-Fi profile names
for /f "tokens=1,2 delims=:" %%a in ('netsh wlan show profiles ^| findstr "All User Profile"') do (
    set "profile=%%b"
    set "profile=!profile:~1!"
    echo Profile: !profile!
    netsh wlan show profile name="!profile!" key=clear | findstr "Key Content"
    echo.
)

echo All done.
pause
