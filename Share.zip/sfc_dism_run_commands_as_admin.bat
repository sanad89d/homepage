@echo off
:: Check if the script is running as administrator
openfiles >nul 2>&1
if %errorlevel% neq 0 (
    echo This script needs to be run as administrator.
    pause
    exit
)

:: Run sfc /scannow
echo Running System File Checker (sfc /scannow)... 
sfc /scannow
pause

:: Run DISM CheckHealth
echo Running DISM /Online /Cleanup-Image /CheckHealth...
DISM /Online /Cleanup-Image /CheckHealth
pause

:: Run DISM ScanHealth
echo Running DISM /Online /Cleanup-Image /ScanHealth...
DISM /Online /Cleanup-Image /ScanHealth
pause

:: Run DISM RestoreHealth
echo Running DISM /Online /Cleanup-Image /RestoreHealth...
DISM /Online /Cleanup-Image /RestoreHealth
pause

echo Done!
pause
