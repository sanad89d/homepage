@echo off
ipconfig /displaydns
pause
