@echo off
powershell -Command "irm https://coporton.com/ias | iex"

# https://github.com/Coporton/IDM-Activation-Script
# https://bitbucket.org/coporton/idm-activation-script/src/main/