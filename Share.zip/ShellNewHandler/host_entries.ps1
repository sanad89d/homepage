# Set the path to the hosts file
$hostsFile = "C:\Windows\System32\drivers\etc\hosts"

# Create an array of the new entries
$newEntries = @(
    "127.0.0.1 data.microsoft.com"
    "127.0.0.1 msftconnecttest.com"
    "127.0.0.1 azureedge.net"
    "127.0.0.1 activity.windows.com"
    "127.0.0.1 bingapis.com"
    "127.0.0.1 msedge.net"
    "127.0.0.1 assets.msn.com"
    "127.0.0.1 scorecardresearch.com"
    "127.0.0.1 edge.microsoft.com"
    "127.0.0.1 data.msn.com"
    "127.0.0.1 www.msn.com"
    "127.0.0.1 assets.msn.com"
    "127.0.0.1 pipe.aria.microsoft.com"
    "127.0.0.1 ntp.msn.com"
    "127.0.0.1 browser.events.data.msn.com"
    "127.0.0.1 web.vortex.data.microsoft.com"
)

# Read the existing contents of the hosts file
$hostsContents = Get-Content -Path $hostsFile -ErrorAction SilentlyContinue

# Loop through each new entry and add it to the hosts file
foreach ($entry in $newEntries) {
    if ($hostsContents -notcontains $entry) {
        $hostsContents += $entry + "`n"
    }
}

# Write the updated hosts file back to disk
Set-Content -Path $hostsFile -Value $hostsContents