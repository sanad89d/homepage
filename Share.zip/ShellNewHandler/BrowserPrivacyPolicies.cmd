@echo off
setlocal EnableExtensions
title Windows Privacy / Browser Policy Configuration

echo.
echo ============================================================
echo   Windows Privacy / Browser Policy Configuration
echo ============================================================
echo.
echo This script requires Administrator privileges.
echo.

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo ERROR: Please right-click this file and select:
    echo        Run as administrator
    echo.
    pause
    exit /b 1
)

echo Applying Vivaldi policies...
reg add "HKLM\SOFTWARE\Policies\Vivaldi" /v "AIModeSettings" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Vivaldi" /v "AutofillPredictionSettings" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Vivaldi" /v "CreateThemesSettings" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Vivaldi" /v "GeminiActOnWebSettings" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Vivaldi" /v "GeminiSettings" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Vivaldi" /v "GenAILocalFoundationalModelSettings" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Vivaldi" /v "HistorySearchSettings" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Vivaldi" /v "TabCompareSettings" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Vivaldi" /v "SpellcheckEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Vivaldi" /v "PasswordManagerEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Vivaldi" /v "PaymentMethodQueryEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Vivaldi" /v "AutofillCreditCardEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Vivaldi" /v "AutofillAddressEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Vivaldi" /v "SyncDisabled" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Vivaldi" /v "BrowserSignin" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Vivaldi" /v "SearchSuggestEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Vivaldi" /v "BlockThirdPartyCookies" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Vivaldi" /v "DefaultGeolocationSetting" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Vivaldi" /v "DefaultNotificationsSetting" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Vivaldi" /v "DefaultSensorsSetting" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Vivaldi" /v "DefaultClipboardSetting" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Vivaldi" /v "TranslateEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Vivaldi" /v "NetworkPredictionOptions" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Vivaldi" /v "HighEfficiencyModeEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Vivaldi" /v "LiveTranslateEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Vivaldi" /v "BackgroundModeEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Vivaldi" /v "BuiltInDnsClientEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Vivaldi" /v "DefaultBrowserSettingEnabled" /t REG_DWORD /d 0 /f

reg add "HKLM\SOFTWARE\Policies\Vivaldi\ClearBrowsingDataOnExitList" /v "1" /t REG_SZ /d "browsing_history" /f
reg add "HKLM\SOFTWARE\Policies\Vivaldi\ClearBrowsingDataOnExitList" /v "2" /t REG_SZ /d "download_history" /f
reg add "HKLM\SOFTWARE\Policies\Vivaldi\ClearBrowsingDataOnExitList" /v "3" /t REG_SZ /d "cookies_and_other_site_data" /f
reg add "HKLM\SOFTWARE\Policies\Vivaldi\ClearBrowsingDataOnExitList" /v "4" /t REG_SZ /d "cached_images_and_files" /f
reg add "HKLM\SOFTWARE\Policies\Vivaldi\ClearBrowsingDataOnExitList" /v "5" /t REG_SZ /d "password_signin" /f
reg add "HKLM\SOFTWARE\Policies\Vivaldi\ClearBrowsingDataOnExitList" /v "6" /t REG_SZ /d "autofill" /f
reg add "HKLM\SOFTWARE\Policies\Vivaldi\ClearBrowsingDataOnExitList" /v "7" /t REG_SZ /d "site_settings" /f
reg add "HKLM\SOFTWARE\Policies\Vivaldi\ClearBrowsingDataOnExitList" /v "8" /t REG_SZ /d "hosted_app_data" /f


echo.
echo Applying Helium policies...

reg add "HKLM\SOFTWARE\Policies\Helium" /v "SpellcheckEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Helium" /v "PasswordManagerEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Helium" /v "PaymentMethodQueryEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Helium" /v "AutofillCreditCardEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Helium" /v "AutofillAddressEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Helium" /v "SyncDisabled" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Helium" /v "BrowserSignin" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Helium" /v "SearchSuggestEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Helium" /v "BlockThirdPartyCookies" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Helium" /v "DefaultGeolocationSetting" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Helium" /v "DefaultNotificationsSetting" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Helium" /v "DefaultSensorsSetting" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Helium" /v "DefaultClipboardSetting" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Helium" /v "TranslateEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Helium" /v "NetworkPredictionOptions" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Helium" /v "HighEfficiencyModeEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Helium" /v "BackgroundModeEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Helium" /v "BuiltInDnsClientEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Helium" /v "DefaultBrowserSettingEnabled" /t REG_DWORD /d 0 /f

reg add "HKLM\SOFTWARE\Policies\Helium\ClearBrowsingDataOnExitList" /v "1" /t REG_SZ /d "browsing_history" /f
reg add "HKLM\SOFTWARE\Policies\Helium\ClearBrowsingDataOnExitList" /v "2" /t REG_SZ /d "download_history" /f
reg add "HKLM\SOFTWARE\Policies\Helium\ClearBrowsingDataOnExitList" /v "3" /t REG_SZ /d "cookies_and_other_site_data" /f
reg add "HKLM\SOFTWARE\Policies\Helium\ClearBrowsingDataOnExitList" /v "4" /t REG_SZ /d "cached_images_and_files" /f
reg add "HKLM\SOFTWARE\Policies\Helium\ClearBrowsingDataOnExitList" /v "5" /t REG_SZ /d "password_signin" /f
reg add "HKLM\SOFTWARE\Policies\Helium\ClearBrowsingDataOnExitList" /v "6" /t REG_SZ /d "autofill" /f
reg add "HKLM\SOFTWARE\Policies\Helium\ClearBrowsingDataOnExitList" /v "7" /t REG_SZ /d "site_settings" /f
reg add "HKLM\SOFTWARE\Policies\Helium\ClearBrowsingDataOnExitList" /v "8" /t REG_SZ /d "hosted_app_data" /f


echo.
echo Applying Microsoft Edge policies...

reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "GenAILocalFoundationalModelSettings" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "AIGenThemesEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "BuiltInAIAPIsEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "CopilotPageContext" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "EdgeEntraCopilotPageContext" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "ComposeInlineEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "EdgeHistoryAISearchEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "Microsoft365CopilotChatIconEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "TextPredictionEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "SpellcheckEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "PasswordManagerEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "PaymentMethodQueryEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "AutofillCreditCardEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "AutofillAddressEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "EdgeAutofillMlEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "SyncDisabled" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "BrowserSignin" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "WebToBrowserSignInEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "SearchSuggestEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "BlockThirdPartyCookies" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "DefaultGeolocationSetting" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "DefaultNotificationsSetting" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "DefaultSensorsSetting" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "DefaultClipboardSetting" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "TranslateEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "NetworkPredictionOptions" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "BuiltInDnsClientEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "EfficiencyModeEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "BackgroundModeEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "StartupBoostEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "AutoImportAtFirstRun" /t REG_DWORD /d 4 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "DefaultBrowserSettingEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "DefaultBrowserSettingsCampaignEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "ShowRecommendationsEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "SpotlightExperiencesAndRecommendationsEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "HideFirstRunExperience" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "ShowPDFDefaultRecommendationsEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "ShowMicrosoftRewards" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "EdgeShoppingAssistantEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "VisualSearchEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "TabServicesEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "DiagnosticData" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "NewTabPageSearchBox" /t REG_SZ /d "redirect" /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "NewTabPageBingChatEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "NewTabPageContentEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "NewTabPageHideDefaultTopSites" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "ShowAcrobatSubscriptionButton" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "LiveVideoTranslationEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "DefaultShareAdditionalOSRegionSetting" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "ScarewareBlockerProtectionEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "SmartScreenEnabled" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "ScarewareBlockerBlocksDetectedSitesEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "ClearBrowsingDataOnExit" /t REG_DWORD /d 1 /f


echo.
echo Applying Google Chrome policies...

reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v "AIModeSettings" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v "AutofillPredictionSettings" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v "CreateThemesSettings" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v "DevToolsGenAiSettings" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v "GeminiActOnWebSettings" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v "GeminiSettings" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v "GenAILocalFoundationalModelSettings" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v "HelpMeWriteSettings" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v "HistorySearchSettings" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v "TabCompareSettings" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v "SpellcheckEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v "PasswordManagerEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v "PaymentMethodQueryEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v "AutofillCreditCardEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v "AutofillAddressEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v "SyncDisabled" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v "BrowserSignin" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v "SearchSuggestEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v "BlockThirdPartyCookies" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v "DefaultGeolocationSetting" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v "DefaultNotificationsSetting" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v "DefaultSensorsSetting" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v "DefaultClipboardSetting" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v "TranslateEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v "NetworkPredictionOptions" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v "HighEfficiencyModeEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v "LiveTranslateEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v "BackgroundModeEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v "BuiltInDnsClientEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v "DefaultBrowserSettingEnabled" /t REG_DWORD /d 0 /f

reg add "HKLM\SOFTWARE\Policies\Google\Chrome\ClearBrowsingDataOnExitList" /v "1" /t REG_SZ /d "browsing_history" /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome\ClearBrowsingDataOnExitList" /v "2" /t REG_SZ /d "download_history" /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome\ClearBrowsingDataOnExitList" /v "3" /t REG_SZ /d "cookies_and_other_site_data" /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome\ClearBrowsingDataOnExitList" /v "4" /t REG_SZ /d "cached_images_and_files" /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome\ClearBrowsingDataOnExitList" /v "5" /t REG_SZ /d "password_signin" /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome\ClearBrowsingDataOnExitList" /v "6" /t REG_SZ /d "autofill" /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome\ClearBrowsingDataOnExitList" /v "7" /t REG_SZ /d "site_settings" /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome\ClearBrowsingDataOnExitList" /v "8" /t REG_SZ /d "hosted_app_data" /f


echo.
echo Applying Brave policies...

reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "BraveAIChatEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "AIModeSettings" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "AutofillPredictionSettings" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "CreateThemesSettings" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "DevToolsGenAiSettings" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "GeminiActOnWebSettings" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "GeminiSettings" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "GenAILocalFoundationalModelSettings" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "HelpMeWriteSettings" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "HistorySearchSettings" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "TabCompareSettings" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "SpellcheckEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "PasswordManagerEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "PaymentMethodQueryEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "AutofillCreditCardEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "AutofillAddressEnabled" /t REG_DWORD /d 0 /f

REM Brave Sync intentionally ENABLED
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "SyncDisabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "BrowserSignin" /t REG_DWORD /d 0 /f

reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "SearchSuggestEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "BlockThirdPartyCookies" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "DefaultGeolocationSetting" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "DefaultNotificationsSetting" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "DefaultSensorsSetting" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "DefaultClipboardSetting" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "TranslateEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "NetworkPredictionOptions" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "HighEfficiencyModeEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "LiveTranslateEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "BackgroundModeEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "BuiltInDnsClientEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "DefaultBrowserSettingEnabled" /t REG_DWORD /d 0 /f

reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "BraveRewardsDisabled" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "BraveWalletDisabled" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "BraveVPNDisabled" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "TorDisabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "BraveP3AEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "BraveStatsPingEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "BraveWebDiscoveryEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "BraveNewsDisabled" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "BraveTalkDisabled" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "BraveSpeedreaderEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "BraveWaybackMachineEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "BravePlaylistEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "DnsOverHttpsMode" /t REG_SZ /d "secure" /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "DnsOverHttpsTemplates" /t REG_SZ /d "https://cloudflare-dns.com/dns-query" /f

reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave\ClearBrowsingDataOnExitList" /v "1" /t REG_SZ /d "browsing_history" /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave\ClearBrowsingDataOnExitList" /v "2" /t REG_SZ /d "download_history" /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave\ClearBrowsingDataOnExitList" /v "3" /t REG_SZ /d "cookies_and_other_site_data" /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave\ClearBrowsingDataOnExitList" /v "4" /t REG_SZ /d "cached_images_and_files" /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave\ClearBrowsingDataOnExitList" /v "5" /t REG_SZ /d "password_signin" /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave\ClearBrowsingDataOnExitList" /v "6" /t REG_SZ /d "autofill" /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave\ClearBrowsingDataOnExitList" /v "7" /t REG_SZ /d "site_settings" /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave\ClearBrowsingDataOnExitList" /v "8" /t REG_SZ /d "hosted_app_data" /f


echo.
echo ============================================================
echo   Applying Windows privacy / recommendation policies
echo ============================================================
echo.

reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\CloudContent" /v "DisableWindowsConsumerFeatures" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\CloudContent" /v "DisableConsumerAccountStateContent" /t REG_DWORD /d 1 /f

reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsCopilot" /v "TurnOffWindowsCopilot" /t REG_DWORD /d 1 /f

reg add "HKCU\Software\Policies\Microsoft\Windows\CloudContent" /v "DisableWindowsConsumerFeatures" /t REG_DWORD /d 1 /f

reg add "HKCU\Software\Policies\Microsoft\Windows\Explorer" /v "DisableStartSuggestions" /t REG_DWORD /d 1 /f

reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Start" /v "HideRecommendedApps" /t REG_DWORD /d 1 /f

reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Search" /v "BingSearchEnabled" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Search" /v "CortanaEnabled" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Search" /v "AllowCortana" /t REG_DWORD /d 0 /f

reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Store" /v "DisableStore" /t REG_DWORD /d 1 /f

reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "Start_Tracking" /t REG_DWORD /d 0 /f

reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" /v "DisableOSUpgrade" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" /v "DisableFeaturedApps" /t REG_DWORD /d 1 /f


echo.
echo ============================================================
echo   Refreshing Windows policy
echo ============================================================
echo.

gpupdate /force

echo.
echo ============================================================
echo   COMPLETE
echo ============================================================
echo.
echo Browser and Windows policies have been written to the
echo Windows Registry.
echo.
echo Some browser policies require the browser to be restarted.
echo A Windows restart is recommended.
echo.
pause
endlocal