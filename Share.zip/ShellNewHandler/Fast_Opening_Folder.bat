@echo off
reg add "HKCU\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\Shell\Bags\AllFolders\Shell" /v FolderType /d "NotSpecified" /f
taskkill /im explorer.exe /f
start explorer.exe
