@echo off
:: Hide Language Bar
echo Hiding Language Bar...
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v "HideLanguageBar" /t REG_DWORD /d 1 /f

:: Disable Language Bar options (make sure it's transparent, no additional icons, no text labels)
echo Disabling Language Bar settings...
reg add "HKCU\Control Panel\International" /v "EnableLanguageBar" /t REG_SZ /d "0" /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "ShowLanguageBar" /t REG_DWORD /d 0 /f

:: Run PowerShell script to set the default language list to en-US and force it
echo Setting language list to en-US...
powershell -Command "Set-WinUserLanguageList en-US -Force"

echo Done. The language bar is hidden, and the language list has been set to en-US.
pause
