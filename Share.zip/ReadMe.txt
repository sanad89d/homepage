https://www.sordum.org/9480/defender-control-v2-1/

https://forums.mydigitallife.net/threads/office-r-tool-project.84450/


# PowerISO

Y9N78-YR4PD-NF45C-N162S-5WU8S
I1RX9-9CHC6-CVQ1A-JSNNV-NHQAW
YB824-TJAMR-PE4NK-GKDFR-FJZ75
HGJA4-JZYDT-GVJMW-N5TCL-SWGMY
ZXBBJ-DBVML-3DWFL-3IL2Y-XRLMN
PKYT6-IEF5X-Q3Y2R-JYXTM-SH7DD

https://github.com/kamrullab/PowerISO

User Name-: Hardik
Registration code :- TZXZT-USMCB-ZRKYP-MTVG3-JM8UL


user : RLTS Team
key : 3YEMI-GLMU6-L9KEC-PA8IR-ZL8KN


user : AbbasPC.Net
key : 48AQS-HUKKQ-NQP4K-3MQR3-K8Z7H

https://gist.github.com/Hardikanand1st/45719f84ed610225535b30c83e0b1182