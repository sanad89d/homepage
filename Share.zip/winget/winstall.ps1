# https://github.com/microsoft/winget-cli/releases

winget install --id=CrystalDewWorld.CrystalDiskInfo -e  ; winget install --id=REALiX.HWiNFO -e  ; winget install --id=Klocman.BulkCrapUninstaller -e  ; winget install --id=nomacs.nomacs -e  ; winget install --id=Microsoft.VCRedist.2015+.x64 -e  ; winget install --id=Microsoft.VCRedist.2015+.x86 -e  ; winget install --id=SumatraPDF.SumatraPDF -e  ; winget install --id=CodeSector.TeraCopy -e  ; winget install --id=M2Team.NanaZip -e  ; winget install --id=9NKSQGP7F2NH -e


# irm https://christitus.com/win | iex
# https://github.com/ChrisTitusTech/winutil

# winget install --id=7zip.7zip -e 