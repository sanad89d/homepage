@echo off
echo Starting program upgradation ...

:: upgrade CrystalDiskInfo
winget upgrade -e --id CrystalDewWorld.CrystalDiskInfo
if %ERRORLEVEL% neq 0 (
    echo Failed to upgrade CrystalDiskInfo.
    pause
    exit /b
)

:: upgrade HWiNFO
winget upgrade -e --id REALiX.HWiNFO
if %ERRORLEVEL% neq 0 (
    echo Failed to upgrade HWiNFO.
    pause
    exit /b
)

:: upgrade Bulk Crap Unupgradeer
winget upgrade -e --id Klocman.BulkCrapUnupgradeer
if %ERRORLEVEL% neq 0 (
    echo Failed to upgrade BulkCrapUnupgradeer.
    pause
    exit /b
)

:: upgrade nomacs
winget upgrade -e --id nomacs.nomacs
if %ERRORLEVEL% neq 0 (
    echo Failed to upgrade nomacs.
    pause
    exit /b
)

:: upgrade Microsoft Visual C++ Redistributable (x64)
winget upgrade -e --id Microsoft.VCRedist.2015+.x64
if %ERRORLEVEL% neq 0 (
    echo Failed to upgrade Microsoft VCRedist 2015+ (x64).
    pause
    exit /b
)

:: upgrade Microsoft Visual C++ Redistributable (x86)
winget upgrade -e --id Microsoft.VCRedist.2015+.x86
if %ERRORLEVEL% neq 0 (
    echo Failed to upgrade Microsoft VCRedist 2015+ (x86).
    pause
    exit /b
)

:: upgrade SumatraPDF
winget upgrade -e --id SumatraPDF.SumatraPDF
if %ERRORLEVEL% neq 0 (
    echo Failed to upgrade SumatraPDF.
    pause
    exit /b
)

:: upgrade TeraCopy
winget upgrade -e --id CodeSector.TeraCopy
if %ERRORLEVEL% neq 0 (
    echo Failed to upgrade TeraCopy.
    pause
    exit /b
)

:: upgrade LockHunter
winget upgrade -e --id CrystalRich.LockHunter
if %ERRORLEVEL% neq 0 (
    echo Failed to upgrade LockHunter.
    pause
    exit /b
)

:: upgrade NanaZip
winget upgrade -e --id M2Team.NanaZip
if %ERRORLEVEL% neq 0 (
    echo Failed to upgrade NanaZip.
    pause
    exit /b
)

:: upgrade 9NKSQGP7F2NH (might need to be more specific with the app ID or package name)
winget upgrade -e --id 9NKSQGP7F2NH
if %ERRORLEVEL% neq 0 (
    echo Failed to upgrade 9NKSQGP7F2NH.
    pause
    exit /b
)

echo upgradation complete!
pause
