# upgrade packages using winget
#winget upgrade --id=7zip.7zip --accept-source-agreements --accept-package-agreements -e
winget upgrade --id=CrystalDewWorld.CrystalDiskInfo --accept-source-agreements --accept-package-agreements -e
winget upgrade --id=REALiX.HWiNFO --accept-source-agreements --accept-package-agreements -e
winget upgrade --id=Klocman.BulkCrapUnupgradeer --accept-source-agreements --accept-package-agreements -e
winget upgrade --id=nomacs.nomacs --accept-source-agreements --accept-package-agreements -e
winget upgrade --id=Microsoft.VCRedist.2015+.x64 --accept-source-agreements --accept-package-agreements -e
winget upgrade --id=Microsoft.VCRedist.2015+.x86 --accept-source-agreements --accept-package-agreements -e
winget upgrade --id=9NKSQGP7F2NH --accept-source-agreements --accept-package-agreements -e
winget upgrade --id=SumatraPDF.SumatraPDF --accept-source-agreements --accept-package-agreements -e
winget upgrade --id=CodeSector.TeraCopy --accept-source-agreements --accept-package-agreements -e
winget upgrade --id=M2Team.NanaZip --accept-source-agreements --accept-package-agreements -e
winget upgrade --id=CrystalRich.LockHunter --accept-source-agreements --accept-package-agreements -e
