# Run PowerShell as Administrator

# Set execution policy to Unrestricted (change as necessary)
Set-ExecutionPolicy -ExecutionPolicy Unrestricted -Scope CurrentUser
Set-ExecutionPolicy -ExecutionPolicy Unrestricted -Scope LocalMachine

# List of applications to install using winget
$applications = @(
    "CrystalDewWorld.CrystalDiskInfo",
    "REALiX.HWiNFO",
    "Klocman.BulkCrapUninstaller",
    "nomacs.nomacs",
    "Microsoft.VCRedist.2015+.x64",
    "Microsoft.VCRedist.2015+.x86",
    "SumatraPDF.SumatraPDF",
    "CodeSector.TeraCopy",
    "M2Team.NanaZip",
    "9NKSQGP7F2NH"
    "CrystalRich.LockHunter"
)

# Function to check if an application is installed
function IsAppInstalled($appName) {
    $result = & winget list --exact --id $appName
    
    # Check if the result contains "Installed" to determine installation status
    return $result -match "Installed"
}

# Function to install an application using winget
function InstallApp($appName) {
    Write-Host "Installing $appName ..."
    & winget install --id $appName -e
}

# Install each application if it's not already installed
foreach ($app in $applications) {
    if (-not (IsAppInstalled $app)) {
        InstallApp $app
    } else {
        Write-Host "$app is already installed."
    }
}

# Set execution policy to Unrestricted (change as necessary)
Set-ExecutionPolicy -ExecutionPolicy Restricted -Scope CurrentUser
Set-ExecutionPolicy -ExecutionPolicy Restricted -Scope LocalMachine