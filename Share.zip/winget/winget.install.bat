@echo off
echo Starting program installation ...

:: Install CrystalDiskInfo
winget install -e --id CrystalDewWorld.CrystalDiskInfo
if %ERRORLEVEL% neq 0 (
    echo Failed to install CrystalDiskInfo.
    pause
    exit /b
)

:: Install HWiNFO
winget install -e --id REALiX.HWiNFO
if %ERRORLEVEL% neq 0 (
    echo Failed to install HWiNFO.
    pause
    exit /b
)

:: Install Bulk Crap Uninstaller
winget install -e --id Klocman.BulkCrapUninstaller
if %ERRORLEVEL% neq 0 (
    echo Failed to install BulkCrapUninstaller.
    pause
    exit /b
)

:: Install nomacs
winget install -e --id nomacs.nomacs
if %ERRORLEVEL% neq 0 (
    echo Failed to install nomacs.
    pause
    exit /b
)

:: Install Microsoft Visual C++ Redistributable (x64)
winget install -e --id Microsoft.VCRedist.2015+.x64
if %ERRORLEVEL% neq 0 (
    echo Failed to install Microsoft VCRedist 2015+ (x64).
    pause
    exit /b
)

:: Install Microsoft Visual C++ Redistributable (x86)
winget install -e --id Microsoft.VCRedist.2015+.x86
if %ERRORLEVEL% neq 0 (
    echo Failed to install Microsoft VCRedist 2015+ (x86).
    pause
    exit /b
)

:: Install SumatraPDF
winget install -e --id SumatraPDF.SumatraPDF
if %ERRORLEVEL% neq 0 (
    echo Failed to install SumatraPDF.
    pause
    exit /b
)

:: Install TeraCopy
winget install -e --id CodeSector.TeraCopy
if %ERRORLEVEL% neq 0 (
    echo Failed to install TeraCopy.
    pause
    exit /b
)

:: Install LockHunter
winget install -e --id CrystalRich.LockHunter
if %ERRORLEVEL% neq 0 (
    echo Failed to install LockHunter.
    pause
    exit /b
)

:: Install NanaZip
winget install -e --id M2Team.NanaZip
if %ERRORLEVEL% neq 0 (
    echo Failed to install NanaZip.
    pause
    exit /b
)

:: Install 9NKSQGP7F2NH (might need to be more specific with the app ID or package name)
winget install -e --id 9NKSQGP7F2NH
if %ERRORLEVEL% neq 0 (
    echo Failed to install 9NKSQGP7F2NH.
    pause
    exit /b
)

echo Installation complete!
pause
