Before install software update winget using winget-install.ps1

Open PowerShell as an administrator.

Navigate to the directory where your script (winget-install.ps1) is located: "cd path\to\script"

Run the script by typing: "winget-install.ps1" [without Quotation marks].

Check for update using the link below.
https://github.com/asheroto/winget-install
============================================

Open PowerShell as an administrator.

Enable PowerShell execution "Set-ExecutionPolicy RemoteSigned -Force"

Navigate to the directory where your script (install-apps.ps1) is located: "cd path\to\script"

Run the script by typing: ".\install-apps.ps1" [without Quotation marks].

Revert PowerShell execution "Set-ExecutionPolicy Default -Force"
