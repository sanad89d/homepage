@echo off
powershell -Command "iwr -useb https://christitus.com/win | iex"