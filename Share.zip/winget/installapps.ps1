# Install packages using winget
# winget install --id=7zip.7zip --accept-source-agreements --accept-package-agreements -e
winget install --id=CrystalDewWorld.CrystalDiskInfo --accept-source-agreements --accept-package-agreements -e
winget install --id=REALiX.HWiNFO --accept-source-agreements --accept-package-agreements -e
winget install --id=Klocman.BulkCrapUninstaller --accept-source-agreements --accept-package-agreements -e
winget install --id=nomacs.nomacs --accept-source-agreements --accept-package-agreements -e
winget install --id=Microsoft.VCRedist.2015+.x64 --accept-source-agreements --accept-package-agreements -e
winget install --id=Microsoft.VCRedist.2015+.x86 --accept-source-agreements --accept-package-agreements -e
winget install --id=9NKSQGP7F2NH --accept-source-agreements --accept-package-agreements -e
winget install --id=SumatraPDF.SumatraPDF --accept-source-agreements --accept-package-agreements -e
winget install --id=CodeSector.TeraCopy --accept-source-agreements --accept-package-agreements -e
winget install --id=M2Team.NanaZip --accept-source-agreements --accept-package-agreements -e
winget install --id=CrystalRich.LockHunter --accept-source-agreements --accept-package-agreements -e
