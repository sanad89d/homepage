@echo off
powershell -Command "irm "https://winscript.cc/irm" | iex"
# https://github.com/flick9000/winscript/
