@echo off
Title Checking Internet Connection & Mode 70,4 & color 0B
::-------------------------------------------------------------------------------------
REM First We Check The Status Of The Internet Connection
Call :Check_Connection
::-------------------------------------------------------------------------------------
:Main
Title Your Extrenal IP Address
Mode 50,4 & Color 0A
 for /f "tokens=2 delims=: " %%A in (
   'nslookup myip.opendns.com. resolver1.opendns.com 2^>NUL^|find "Address:" ^| findstr /v "208.67.222.222" '
 ) Do ( 
    If "%%A" NEQ "127.0.0.1" (
        set "ExtIP=%%A"
    ) else (
        Color 0C & echo(
        echo              No internet connection !
    )
 )
 echo(
 If defined ExtIP (
    echo       You are connected to the internet !
    echo       Your External IP is : %ExtIP%
 )
 Pause>nul & Exit
::-------------------------------------------------------------------------------------
:Check_Connection
Title Checking Internet Connection ...
SetLocal EnableDelayedExpansion
Mode 50,3 & Color 0B
echo(
echo(  Please Wait... Checking Internet Connection ...
Timeout /T 1 /NoBreak>nul
Ping www.google.nl -n 1 -w 1000>nul
cls
echo(
if [!errorlevel!] EQU [1] (
    Color 0C & set "internet=Not Connected To Internet"
    echo(  Connection Status : !Internet!
    CMD /C %SystemRoot%\system32\msdt.exe ^
    Skip TRUE -path %Windir%\diagnostics\system\networking -ep NetworkDiagnosticsPNI
    Timeout /T 1 /NoBreak>nul & Goto Check_Connection
) else (
    Color 0A & set "internet=Connected To Internet"
    echo(    Connection Status : !Internet!
    Timeout /T 1 /NoBreak>nul & Goto Main
)
EndLocal
::-------------------------------------------------------------------------------------
